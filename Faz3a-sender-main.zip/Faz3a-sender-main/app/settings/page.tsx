"use client"

import React from "react"
import Navbar from "@/components/navbar"
import AppFooter from "@/components/footer"
import { LanguageProvider, useI18n } from "@/components/language-provider"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import dynamic from "next/dynamic"

const DkimSection = dynamic(() => import("./dkim-section"), { ssr: false })

function SettingsInner() {
  const { t } = useI18n()
  const [host, setHost] = React.useState("")
  const [port, setPort] = React.useState(587)
  const [secure, setSecure] = React.useState(false)
  const [username, setUsername] = React.useState("")
  const [password, setPassword] = React.useState("")
  const [fromEmail, setFromEmail] = React.useState("")
  const [fromName, setFromName] = React.useState("")
  const [msg, setMsg] = React.useState("")

  async function save() {
    const csrf = document.cookie
      .split("; ")
      .find((c) => c.startsWith("csrf_token="))
      ?.split("=")[1]
    const res = await fetch("/api/settings/smtp", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-csrf-token": csrf || "" },
      body: JSON.stringify({ host, port, secure, username, password, fromEmail, fromName }),
    })
    const j = await res.json().catch(() => ({}))
    setMsg(j?.message || "Saved")
  }

  async function test() {
    const csrf = document.cookie
      .split("; ")
      .find((c) => c.startsWith("csrf_token="))
      ?.split("=")[1]
    const res = await fetch("/api/settings/test-email", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-csrf-token": csrf || "" },
      body: JSON.stringify({ to: username }),
    })
    const j = await res.json().catch(() => ({}))
    setMsg(j?.message || "Sent")
  }

  return (
    <main>
      <Navbar />
      <div className="mx-auto max-w-3xl p-4 grid gap-4">
        <Card>
          <CardHeader>
            <CardTitle>{t("smtpConfig")}</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3">
            <Input placeholder="Host" value={host} onChange={(e) => setHost(e.target.value)} />
            <Input
              type="number"
              placeholder="Port"
              value={port}
              onChange={(e) => setPort(Number.parseInt(e.target.value || "0", 10))}
            />
            <div className="flex items-center gap-2">
              <input id="secure" type="checkbox" checked={secure} onChange={(e) => setSecure(e.target.checked)} />
              <label htmlFor="secure" className="text-sm">
                Secure (TLS)
              </label>
            </div>
            <Input placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} />
            <Input
              placeholder="Password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <Input placeholder="From Email" value={fromEmail} onChange={(e) => setFromEmail(e.target.value)} />
            <Input placeholder="From Name" value={fromName} onChange={(e) => setFromName(e.target.value)} />
            <div className="flex gap-2">
              <Button onClick={save}>{t("save")}</Button>
              <Button variant="outline" onClick={test} disabled={!host || !username || !password}>
                {t("testEmail")}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>DKIM / SPF / DMARC</CardTitle>
          </CardHeader>
          <CardContent>
            <DkimSection />
          </CardContent>
        </Card>

        {msg && <p className="text-green-600 text-sm">{msg}</p>}
      </div>
      <AppFooter />
    </main>
  )
}

export default function SettingsPage() {
  return (
    <LanguageProvider>
      <SettingsInner />
    </LanguageProvider>
  )
}
