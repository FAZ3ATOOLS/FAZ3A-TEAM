"use client"

import React from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export default function DkimSection() {
  const [domain, setDomain] = React.useState("")
  const [selector, setSelector] = React.useState("mail")
  const [records, setRecords] = React.useState<any>(null)
  const [privateKey, setPrivateKey] = React.useState<string | null>(null)
  const [msg, setMsg] = React.useState("")

  async function generate() {
    setMsg("")
    const csrf = document.cookie
      .split("; ")
      .find((c) => c.startsWith("csrf_token="))
      ?.split("=")[1]
    const res = await fetch("/api/settings/dkim/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-csrf-token": csrf || "" },
      body: JSON.stringify({ domain, selector }),
    })
    const j = await res.json().catch(() => ({}))
    if (res.ok) {
      setRecords(j.records)
      setPrivateKey(j.privateKey)
      setMsg("DKIM keys generated. Add the DNS records shown below.")
    } else setMsg(j?.error || "Error")
  }

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
        <Input placeholder="Domain (example.com)" value={domain} onChange={(e) => setDomain(e.target.value)} />
        <Input placeholder="Selector (e.g., mail)" value={selector} onChange={(e) => setSelector(e.target.value)} />
      </div>
      <div className="flex gap-2">
        <Button onClick={generate} disabled={!domain || !selector}>
          Generate DKIM
        </Button>
      </div>
      {msg && <p className="text-sm text-green-600">{msg}</p>}
      {records && (
        <div className="text-xs border rounded p-3 space-y-2 bg-muted/30">
          <div>
            <div className="font-semibold">DKIM</div>
            <div>Name: {records.dkim.name}</div>
            <div className="break-all">Value: {records.dkim.value}</div>
          </div>
          <div>
            <div className="font-semibold">SPF</div>
            <div>Name: {records.spf.name}</div>
            <div className="break-all">Value: {records.spf.value}</div>
          </div>
          <div>
            <div className="font-semibold">DMARC</div>
            <div>Name: {records.dmarc.name}</div>
            <div className="break-all">Value: {records.dmarc.value}</div>
          </div>
          {privateKey && (
            <div>
              <div className="font-semibold">Private key (store securely, not in DNS)</div>
              <textarea readOnly className="w-full h-40 p-2 text-xs border rounded" value={privateKey} />
            </div>
          )}
        </div>
      )}
    </div>
  )
}
