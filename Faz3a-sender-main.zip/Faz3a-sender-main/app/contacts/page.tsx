"use client"

import React from "react"
import Navbar from "@/components/navbar"
import AppFooter from "@/components/footer"
import { LanguageProvider, useI18n } from "@/components/language-provider"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Papa from "papaparse"

type Row = { email: string; name?: string }

function ContactsInner() {
  const { t } = useI18n()
  const [rows, setRows] = React.useState<Row[]>([])
  const [fileName, setFileName] = React.useState<string | null>(null)
  const [manualEmail, setManualEmail] = React.useState("")
  const [manualName, setManualName] = React.useState("")
  const [busy, setBusy] = React.useState(false)
  const [msg, setMsg] = React.useState("")

  function onCsv(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0]
    if (!f) return
    setFileName(f.name)
    Papa.parse(f, {
      header: true,
      complete: (res: Papa.ParseResult<any>) => {
        const cleaned: Row[] = []
        for (const r of res.data as any[]) {
          if (r?.email) cleaned.push({ email: String(r.email).trim(), name: (r.name || "").trim() })
        }
        setRows(cleaned)
      },
    })
  }

  async function importRows() {
    setBusy(true)
    setMsg("")
    const csrf = document.cookie
      .split("; ")
      .find((c) => c.startsWith("csrf_token="))
      ?.split("=")[1]
    const res = await fetch("/api/contacts/import", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-csrf-token": csrf || "" },
      body: JSON.stringify({ rows }),
    })
    const j = await res.json().catch(() => ({}))
    setBusy(false)
    setMsg(j?.message || "Done")
  }

  async function addManual() {
    setBusy(true)
    setMsg("")
    const csrf = document.cookie
      .split("; ")
      .find((c) => c.startsWith("csrf_token="))
      ?.split("=")[1]
    const res = await fetch("/api/contacts/create", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-csrf-token": csrf || "" },
      body: JSON.stringify({ email: manualEmail, name: manualName }),
    })
    const j = await res.json().catch(() => ({}))
    setBusy(false)
    setMsg(j?.message || "Done")
    setManualEmail("")
    setManualName("")
  }

  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-1">
        <Navbar />
        <div className="mx-auto max-w-5xl p-4 grid gap-4">
          <Card>
            <CardHeader>
              <CardTitle>{t("importCSV")}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Input type="file" accept=".csv" onChange={onCsv} />
              {fileName && (
                <p className="text-xs text-muted-foreground">
                  Selected: {fileName}, rows: {rows.length}
                </p>
              )}
              {rows.length > 0 && (
                <div className="max-h-64 overflow-auto border rounded p-2 text-xs">
                  {rows.slice(0, 50).map((r, i) => (
                    <div key={i} className="grid grid-cols-2 gap-2">
                      <span>{r.email}</span>
                      <span className="text-muted-foreground">{r.name}</span>
                    </div>
                  ))}
                  {rows.length > 50 && <div className="text-muted-foreground mt-2">...and {rows.length - 50} more</div>}
                </div>
              )}
              <Button disabled={busy || rows.length === 0} onClick={importRows}>
                {t("validate")}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{t("addContact")}</CardTitle>
            </CardHeader>
            <CardContent className="flex gap-2">
              <Input
                placeholder="email@example.com"
                value={manualEmail}
                onChange={(e) => setManualEmail(e.target.value)}
              />
              <Input placeholder="Name (optional)" value={manualName} onChange={(e) => setManualName(e.target.value)} />
              <Button disabled={busy || !manualEmail} onClick={addManual}>
                {t("save")}
              </Button>
            </CardContent>
          </Card>

          {msg && <p className="text-sm text-green-600">{msg}</p>}
        </div>
      </main>
      {/*
        Footer attribution
      */}
      <AppFooter />
    </div>
  )
}

export default function ContactsPage() {
  return (
    <LanguageProvider>
      <ContactsInner />
    </LanguageProvider>
  )
}
