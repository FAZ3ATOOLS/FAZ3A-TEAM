"use client"

import React from "react"
import Navbar from "@/components/navbar"
import AppFooter from "@/components/footer"
import { LanguageProvider, useI18n } from "@/components/language-provider"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import TemplateEditor from "@/components/template-editor"
import { renderTemplate } from "@/lib/mustache"

export default function TemplatesPage() {
  return (
    <LanguageProvider>
      <TemplatesInner />
    </LanguageProvider>
  )
}

function TemplatesInner() {
  const { t } = useI18n()
  const [html, setHtml] = React.useState("<h1>Hello {{name}}</h1><p>Welcome to {{company}}.</p>")
  const [variables, setVariables] = React.useState({ name: "Friend", company: "MailForge" })
  const preview = renderTemplate(html, variables as any)

  async function saveTemplate() {
    const csrf = document.cookie
      .split("; ")
      .find((c) => c.startsWith("csrf_token="))
      ?.split("=")[1]
    await fetch("/api/templates/save", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-csrf-token": csrf || "" },
      body: JSON.stringify({ html }),
    })
    alert("Saved")
  }

  return (
    <main>
      <Navbar />
      <div className="mx-auto max-w-6xl p-4 grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>{t("editor")}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <TemplateEditor value={html} onChange={setHtml} />
            <div className="flex justify-end">
              <Button onClick={saveTemplate}>{t("save")}</Button>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>{t("preview")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="border rounded p-3 overflow-auto max-h-[70vh]">
              <iframe className="w-full h-[60vh] border rounded" srcDoc={preview} />
            </div>
          </CardContent>
        </Card>
      </div>
      <AppFooter />
    </main>
  )
}
