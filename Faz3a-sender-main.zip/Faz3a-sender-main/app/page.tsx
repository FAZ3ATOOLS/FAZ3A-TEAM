"use client"

import React from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { useI18n, LanguageProvider } from "@/components/language-provider"
import AppFooter from "@/components/footer"
import { Shield } from "lucide-react"

function LoginForm() {
  const { t } = useI18n()
  const [email, setEmail] = React.useState("")
  const [password, setPassword] = React.useState("")
  const [error, setError] = React.useState("")
  const [loading, setLoading] = React.useState(false)

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError("")
    setLoading(true)
    try {
      const csrf = document.cookie
        .split("; ")
        .find((c) => c.startsWith("csrf_token="))
        ?.split("=")[1]
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-csrf-token": csrf || "" },
        body: JSON.stringify({ email, password }),
      })
      if (res.ok) {
        window.location.href = "/dashboard"
      } else {
        const j = await res.json().catch(() => ({}))
        setError(j?.error || "Login failed")
      }
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    const existing = document.cookie.split("; ").find((c) => c.startsWith("csrf_token="))
    if (!existing) {
      const token = Math.random().toString(36).slice(2)
      document.cookie = `csrf_token=${token}; Path=/; SameSite=Lax`
    }
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-b from-neutral-50 via-white to-neutral-100 flex flex-col">
      <div className="flex-1 grid place-items-center px-4">
        <Card className="w-full max-w-md shadow-lg border border-neutral-200">
          <CardHeader className="text-center space-y-2">
            <div className="mx-auto h-12 w-12 rounded-full bg-emerald-100 text-emerald-700 grid place-items-center">
              <Shield className="h-6 w-6" />
            </div>
            <CardTitle className="text-xl font-semibold">Sign in to {t("appName")}</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="grid gap-4" onSubmit={onSubmit}>
              <div className="grid gap-1">
                <label className="text-sm">{t("email")}</label>
                <Input
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  type="email"
                  required
                  placeholder="you@company.com"
                />
              </div>
              <div className="grid gap-1">
                <label className="text-sm">{t("password")}</label>
                <Input
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  type="password"
                  required
                  placeholder="••••••••"
                />
              </div>
              {error && <p className="text-sm text-red-600">{error}</p>}
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? "..." : t("signIn")}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
      <AppFooter />
    </div>
  )
}

export default function Page() {
  return (
    <LanguageProvider>
      <LoginForm />
    </LanguageProvider>
  )
}
