import { type NextRequest, NextResponse } from "next/server"
import { assertCsrf, requireAdmin } from "@/lib/auth"
import { sql } from "@/lib/db"
import { randomUUID } from "crypto"
import createDOMPurify from "isomorphic-dompurify"

export async function POST(req: NextRequest) {
  try {
    assertCsrf()
    await requireAdmin(req)
    const { html } = await req.json()
    const clean = createDOMPurify.sanitize(html, { USE_PROFILES: { html: true } })
    const id = randomUUID()
    await sql`insert into templates (id, name, html) values (${id}, ${"Template " + id.slice(0, 8)}, ${clean})`
    return NextResponse.json({ ok: true })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Error" }, { status: 400 })
  }
}
