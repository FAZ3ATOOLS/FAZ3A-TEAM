import { NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function GET() {
  const templates = await sql`select id, name from templates order by created_at desc`
  return NextResponse.json({ templates })
}
