import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function GET(req: NextRequest) {
  const token = req.nextUrl.searchParams.get("t")
  if (!token) return NextResponse.json({ error: "Missing token" }, { status: 400 })
  const rows = await sql`
    update verifications set used=true where token=${token} and used=false returning email
  `
  const email = rows[0]?.email
  if (email) {
    await sql`update contacts set status='active' where email=${email.toLowerCase()}`
    return NextResponse.redirect("/verified")
  }
  return NextResponse.redirect("/invalid-token")
}
