import { type NextRequest, NextResponse } from "next/server"
import { assertCsrf, requireAdmin } from "@/lib/auth"
import { validateEmailAddress } from "@/lib/validation"
import { sql } from "@/lib/db"
import { randomUUID } from "crypto"
import { sendViaExternalSmtp } from "@/lib/mailer"
import { publicBaseUrlFromReq } from "@/lib/url"

export async function POST(req: NextRequest) {
  try {
    assertCsrf()
    const { sub } = await requireAdmin(req)
    const { rows } = (await req.json()) as { rows: { email: string; name?: string }[] }
    if (!Array.isArray(rows)) return NextResponse.json({ error: "Invalid payload" }, { status: 400 })

    const baseUrl = publicBaseUrlFromReq(req)
    const results: { email: string; valid: boolean; reason?: string }[] = []

    for (const r of rows) {
      const v = await validateEmailAddress(r.email)
      if (v.valid) {
        const id = randomUUID()
        await sql`
          insert into contacts (id, email, name, status)
          values (${id}, ${r.email.toLowerCase()}, ${r.name ?? null}, 'pending')
          on conflict (email) do nothing
        `
        const token = randomUUID()
        await sql`
          insert into verifications (id, email, token, created_at, used)
          values (${randomUUID()}, ${r.email.toLowerCase()}, ${token}, now(), false)
        `
        const verifyUrl = `${baseUrl}/api/verification?t=${encodeURIComponent(token)}`
        await sendViaExternalSmtp(sub, {
          to: r.email.toLowerCase(),
          subject: "Confirm your subscription",
          rawHtml: `<p>Please confirm your subscription by clicking the link below:</p><p><a href="${verifyUrl}">${verifyUrl}</a></p>`,
          variables: {},
          token,
          publicBaseUrl: baseUrl,
        })

        results.push({ email: r.email, valid: true })
      } else {
        results.push({ email: r.email, valid: false, reason: v.details })
      }
    }
    return NextResponse.json({ message: `Processed ${results.length} rows`, results })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Error" }, { status: 400 })
  }
}
