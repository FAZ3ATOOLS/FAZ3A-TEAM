import { type NextRequest, NextResponse } from "next/server"
import { assertCsrf, requireAdmin } from "@/lib/auth"
import { validateEmailAddress } from "@/lib/validation"
import { sql } from "@/lib/db"
import { randomUUID } from "crypto"
import { sendViaExternalSmtp } from "@/lib/mailer"
import { publicBaseUrlFromReq } from "@/lib/url"

export async function POST(req: NextRequest) {
  try {
    assertCsrf()
    const { sub } = await requireAdmin(req)
    const { email, name } = await req.json()
    const v = await validateEmailAddress(email)
    if (!v.valid) return NextResponse.json({ error: v.details || "Invalid email" }, { status: 400 })

    const id = randomUUID()
    await sql`
      insert into contacts (id, email, name, status)
      values (${id}, ${email.toLowerCase()}, ${name ?? null}, 'pending')
      on conflict (email) do nothing
    `
    const token = randomUUID()
    await sql`
      insert into verifications (id, email, token, created_at, used)
      values (${randomUUID()}, ${email.toLowerCase()}, ${token}, now(), false)
    `
    const baseUrl = publicBaseUrlFromReq(req)
    const verifyUrl = `${baseUrl}/api/verification?t=${encodeURIComponent(token)}`
    await sendViaExternalSmtp(sub, {
      to: email.toLowerCase(),
      subject: "Confirm your subscription",
      rawHtml: `<p>Please confirm your subscription by clicking the link below:</p><p><a href="${verifyUrl}">${verifyUrl}</a></p>`,
      variables: {},
      token,
      publicBaseUrl: baseUrl,
    })

    return NextResponse.json({ message: "Contact added. Verification sent." })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Error" }, { status: 400 })
  }
}
