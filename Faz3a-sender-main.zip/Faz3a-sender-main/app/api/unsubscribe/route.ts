import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function POST(req: NextRequest) {
  const { email } = await req.json()
  if (!email) return NextResponse.json({ error: "Email required" }, { status: 400 })
  await sql`update contacts set status='unsubscribed' where email=${email.toLowerCase()}`
  return NextResponse.json({ ok: true })
}
