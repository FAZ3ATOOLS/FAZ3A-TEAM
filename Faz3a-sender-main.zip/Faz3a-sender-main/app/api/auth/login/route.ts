import { type NextRequest, NextResponse } from "next/server"
import { assertCsrf, issueSessionTokens, verifyPassword } from "@/lib/auth"
import { sql } from "@/lib/db"
import { checkRateLimit } from "@/lib/rate-limit"
import { logActivity } from "@/lib/activity"

export async function POST(req: NextRequest) {
  try {
    assertCsrf()
    const clientIP = req.headers.get("x-forwarded-for") || req.headers.get("x-real-ip") || "unknown"
    const key = `login:${clientIP}`
    const allowed = await checkRateLimit(key, 20, 60)
    if (!allowed) return NextResponse.json({ error: "Too many attempts" }, { status: 429 })

    const { email, password } = await req.json()
    const rows = await sql`
      select id, email, password_hash, role, status from users where email = ${email.toLowerCase()} limit 1
    `
    const user = rows[0]
    if (!user) return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    if (user.status === "disabled") return NextResponse.json({ error: "User disabled" }, { status: 403 })
    const ok = await verifyPassword(password, user.password_hash)
    if (!ok) return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })

    const { access, refresh } = await issueSessionTokens(user.id, user.role)
    await sql`update users set last_login_at=now() where id=${user.id}`
    await logActivity(user.id, "LOGIN", { ip: clientIP })

    const res = NextResponse.json({ ok: true })
    res.cookies.set("access_token", access, { httpOnly: true, sameSite: "lax", secure: true, path: "/" })
    res.cookies.set("refresh_token", refresh, { httpOnly: true, sameSite: "lax", secure: true, path: "/" })
    return res
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Error" }, { status: 400 })
  }
}
