import { NextResponse, type NextRequest } from "next/server"
import { rotateRefreshToken } from "@/lib/auth"

export async function POST(req: NextRequest) {
  try {
    const token = req.cookies.get("refresh_token")?.value
    if (!token) return NextResponse.json({ error: "Missing refresh token" }, { status: 401 })
    const { access, refresh } = await rotateRefreshToken(token)
    const res = NextResponse.json({ ok: true })
    res.cookies.set("access_token", access, { httpOnly: true, sameSite: "lax", secure: true, path: "/" })
    res.cookies.set("refresh_token", refresh, { httpOnly: true, sameSite: "lax", secure: true, path: "/" })
    return res
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Error" }, { status: 401 })
  }
}
