import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { sendViaExternalSmtp, sendDirectToMx, throttleOk, resolveRecipientMx } from "@/lib/mailer"
import { publicBaseUrlFromReq } from "@/lib/url"
import { computeBackoffSeconds } from "@/lib/backoff"
import { canSendForUser } from "@/lib/quotas"

// Protected by CRON_SECRET; accept either X-Cron-Secret or Authorization: Bearer per Vercel docs [^1].
function checkCronAuth(req: NextRequest) {
  const sec = process.env.CRON_SECRET
  if (!sec) throw new Error("CRON_SECRET not configured")
  const hdr = req.headers.get("x-cron-secret")
  const auth = req.headers.get("authorization")
  const ok = hdr === sec || auth === `Bearer ${sec}`
  if (!ok) {
    const e: any = new Error("Forbidden")
    e.status = 403
    throw e
  }
}

export async function GET(req: NextRequest) {
  try {
    checkCronAuth(req)
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Forbidden" }, { status: e.status || 403 })
  }

  const limit = Number.parseInt(process.env.BATCH_SIZE || "25", 10)

  const rows = await sql`
    select id, user_id, campaign_id, to_email, subject, html, retries, sending_mode, token, run_after
    from queue
    where status = 'pending' and run_after <= now()
    order by created_at asc
    limit ${limit}
  `

  const publicBaseUrl = publicBaseUrlFromReq(req)
  let sent = 0
  for (const job of rows) {
    try {
      // Quota enforcement
      const quota = await canSendForUser(job.user_id, job.campaign_id)
      if (!quota.ok) {
        const bump = quota.reason?.includes("daily") ? "24 hours" : "2 hours"
        await sql`update queue set run_after=now() + (${bump})::interval where id=${job.id}`
        continue
      }

      // Per domain/MX throttling
      const { domain, mxHost } = await resolveRecipientMx(job.to_email)
      const allowed = await throttleOk(domain, mxHost)
      if (!allowed) {
        await sql`update queue set run_after = now() + interval '60 seconds' where id=${job.id}`
        continue
      }

      const sendSmtp = async () =>
        sendViaExternalSmtp(job.user_id, {
          to: job.to_email,
          subject: job.subject,
          rawHtml: job.html,
          variables: {},
          token: job.token,
          publicBaseUrl,
        })

      const sendDirect = async () => sendDirectToMx()

      const mode = job.sending_mode
      if (mode === "smtp") {
        await sendSmtp()
      } else if (mode === "direct") {
        await sendDirect()
      } else {
        try {
          await sendDirect()
        } catch {
          await sendSmtp()
        }
      }

      await sql`update queue set status='sent', sent_at=now(), error=null where id=${job.id}`
      sent++
    } catch (e: any) {
      const hard = /Recipient address rejected|User unknown|550\b/.test(String(e?.message || ""))
      if (hard) {
        await sql`update queue set status='bounced', error=${String(e?.message || "")} where id=${job.id}`
        await sql`update contacts set status='bounced' where email=${job.to_email.toLowerCase()}`
      } else {
        const nextRetries = job.retries + 1
        const backoffSec = computeBackoffSeconds(nextRetries)
        await sql`
          update queue set retries=${nextRetries}, run_after=now() + (${backoffSec} || ' seconds')::interval
          where id=${job.id}
        `
      }
    }
  }

  return NextResponse.json({ processed: rows.length, sent })
}
