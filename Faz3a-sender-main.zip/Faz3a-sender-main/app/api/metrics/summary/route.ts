import { NextResponse, type NextRequest } from "next/server"
import { sql } from "@/lib/db"
import { requireAdmin } from "@/lib/auth"

export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req)
    const [opens] = await sql`
      select count(*)::int as count from events where type='open' and created_at > now() - interval '30 days'
    `
    const [clicks] = await sql`
      select count(*)::int as count from events where type='click' and created_at > now() - interval '30 days'
    `
    const [bounces] = await sql`
      select count(*)::int as count from queue where status='bounced' and sent_at > now() - interval '30 days'
    `
    const perCampaign = await sql`
      with sent as (
        select campaign_id, count(*)::int as sent
        from queue
        where status='sent'
        group by campaign_id
      ),
      e_open as (
        select q.campaign_id, count(*)::int as opens
        from events e
        join queue q on q.token = e.token
        where e.type='open'
        group by q.campaign_id
      ),
      e_click as (
        select q.campaign_id, count(*)::int as clicks
        from events e
        join queue q on q.token = e.token
        where e.type='click'
        group by q.campaign_id
      )
      select c.id as campaign_id, c.name,
        coalesce(s.sent,0) as sent,
        coalesce(o.opens,0) as opens,
        coalesce(k.clicks,0) as clicks
      from campaigns c
      left join sent s on s.campaign_id = c.id
      left join e_open o on o.campaign_id = c.id
      left join e_click k on k.campaign_id = c.id
      order by c.created_at desc
      limit 5
    `
    return NextResponse.json({
      opens: opens?.count ?? 0,
      clicks: clicks?.count ?? 0,
      bounces: bounces?.count ?? 0,
      perCampaign,
    })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Error" }, { status: 401 })
  }
}
