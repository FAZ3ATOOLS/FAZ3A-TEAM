import { NextResponse, type NextRequest } from "next/server"
import { requireUser } from "@/lib/auth"
import { sql } from "@/lib/db"

export async function GET(req: NextRequest) {
  try {
    const payload = await requireUser(req)
    const [u] = await sql`
      select id, email, role, status from users where id=${payload.sub} limit 1
    `
    if (!u) return NextResponse.json({ error: "User not found" }, { status: 404 })
    return NextResponse.json(u)
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Unauthorized" }, { status: 401 })
  }
}
