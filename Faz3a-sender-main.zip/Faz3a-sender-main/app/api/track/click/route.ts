import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function GET(req: NextRequest) {
  const url = req.nextUrl.searchParams.get("u")
  const token = req.nextUrl.searchParams.get("t")
  if (token) {
    await sql`insert into events (type, token, meta) values ('click', ${token}, ${JSON.stringify({ url })})`
  }
  if (url && /^https?:\/\//i.test(url)) {
    return NextResponse.redirect(url)
  }
  return NextResponse.redirect("/")
}
