import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function GET(req: NextRequest) {
  try {
    const token = req.nextUrl.searchParams.get("t")
    if (token) {
      await sql`insert into events (type, token, meta) values ('open', ${token}, '{}')`
    }
    // Return 1x1 transparent PNG
    const png = Buffer.from(
      "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR4nGPg+A8AAn8B9rHV/4sAAAAASUVORK5CYII=",
      "base64",
    )
    return new NextResponse(png, { headers: { "Content-Type": "image/png", "Cache-Control": "no-store" } })
  } catch {
    return new NextResponse(null, { status: 204 })
  }
}
