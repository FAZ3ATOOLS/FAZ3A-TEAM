import { NextResponse, type NextRequest } from "next/server"
import { requireAdmin } from "@/lib/auth"
import { sql } from "@/lib/db"

export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req)
    const limit = Math.min(500, Number(req.nextUrl.searchParams.get("limit") || 100))
    const rows = await sql`
      select l.id, l.user_id, l.action, l.meta, l.created_at, u.email
      from user_activity_logs l
      left join users u on u.id=l.user_id
      order by l.created_at desc
      limit ${limit}
    `
    return NextResponse.json({ logs: rows })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Unauthorized" }, { status: 401 })
  }
}
