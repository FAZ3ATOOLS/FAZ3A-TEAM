import { type NextRequest, NextResponse } from "next/server"
import { assertCsrf, requireAdmin, hashPassword } from "@/lib/auth"
import { sql } from "@/lib/db"
import { logActivity } from "@/lib/activity"

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    assertCsrf()
    const admin = await requireAdmin(req)
    const { role, status, daily_quota, campaign_quota, password } = await req.json()
    if (password) {
      const hash = await hashPassword(password)
      await sql`
        update users set password_hash=${hash}, role=${role}, status=${status},
          daily_quota=${daily_quota ?? 0}, campaign_quota=${campaign_quota ?? 0}, updated_at=now()
        where id=${params.id}
      `
    } else {
      await sql`
        update users set role=${role}, status=${status},
          daily_quota=${daily_quota ?? 0}, campaign_quota=${campaign_quota ?? 0}, updated_at=now()
        where id=${params.id}
      `
    }
    await logActivity(admin.sub, "UPDATE_USER", { id: params.id, role, status, daily_quota, campaign_quota })
    return NextResponse.json({ ok: true })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Error" }, { status: 400 })
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    assertCsrf()
    const admin = await requireAdmin(req)
    await sql`delete from users where id=${params.id}`
    await logActivity(admin.sub, "DELETE_USER", { id: params.id })
    return NextResponse.json({ ok: true })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Error" }, { status: 400 })
  }
}
