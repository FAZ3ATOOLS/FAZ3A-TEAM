import { type NextRequest, NextResponse } from "next/server"
import { assertCsrf, requireAdmin, hashPassword } from "@/lib/auth"
import { sql } from "@/lib/db"
import { randomUUID } from "crypto"
import { logActivity } from "@/lib/activity"

export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req)
    const users = await sql`
      select id, email, role, status, daily_quota, campaign_quota, created_at
      from users
      order by created_at desc nulls last, email asc
    `
    return NextResponse.json({ users })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Unauthorized" }, { status: 401 })
  }
}

export async function POST(req: NextRequest) {
  try {
    assertCsrf()
    const admin = await requireAdmin(req)
    const { email, password, role, status, daily_quota, campaign_quota } = await req.json()
    if (!email || !password) return NextResponse.json({ error: "email and password required" }, { status: 400 })
    const hash = await hashPassword(password)
    const id = randomUUID()
    await sql`
      insert into users (id, email, password_hash, role, status, daily_quota, campaign_quota, created_at, updated_at)
      values (${id}, ${email.toLowerCase()}, ${hash}, ${role || "user"}, ${status || "active"},
              ${daily_quota ?? 0}, ${campaign_quota ?? 0}, now(), now())
    `
    await logActivity(admin.sub, "CREATE_USER", { id, email, role, daily_quota, campaign_quota })
    return NextResponse.json({ ok: true, id })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Error" }, { status: 400 })
  }
}
