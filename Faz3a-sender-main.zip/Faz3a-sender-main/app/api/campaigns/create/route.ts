import { type NextRequest, NextResponse } from "next/server"
import { assertCsrf, requireAdmin } from "@/lib/auth"
import { sql } from "@/lib/db"
import { randomUUID } from "crypto"

export async function POST(req: NextRequest) {
  try {
    assertCsrf()
    await requireAdmin(req)
    const { name, templateId, subject } = await req.json()
    if (!name || !templateId || !subject) return NextResponse.json({ error: "Missing fields" }, { status: 400 })

    const [tpl] = await sql`
      select id, html from templates where id=${templateId} limit 1
    `
    if (!tpl) return NextResponse.json({ error: "Template not found" }, { status: 404 })

    const campaignId = randomUUID()
    await sql`insert into campaigns (id, name, template_id) values (${campaignId}, ${name}, ${templateId})`

    // Enqueue for all active contacts.
    const contacts = await sql`
      select email, name from contacts where status='active'
    `
    let enqueued = 0
    for (const c of contacts) {
      const token = randomUUID()
      const id = randomUUID()
      await sql`
        insert into queue (id, user_id, campaign_id, to_email, subject, html, status, token, sending_mode)
        values (${id}, (select id from users order by created_at nulls last limit 1), ${campaignId}, ${c.email.toLowerCase()},
                ${subject}, ${tpl.html}, 'pending', ${token}, 'auto')
      `
      enqueued++
    }
    return NextResponse.json({ ok: true, campaignId, enqueued })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Error" }, { status: 400 })
  }
}
