import { type NextRequest, NextResponse } from "next/server"
import { assertCsrf, requireAdmin } from "@/lib/auth"
import { sendViaExternalSmtp } from "@/lib/mailer"

export async function POST(req: NextRequest) {
  try {
    assertCsrf()
    const { sub } = await requireAdmin(req)
    const { to } = await req.json()
    await sendViaExternalSmtp(sub, {
      to,
      subject: "Test Email",
      rawHtml: "<p>This is a test email from MailForge.</p>",
      variables: {},
      token: "test",
      publicBaseUrl: "http://localhost:3000",
    })
    return NextResponse.json({ message: "Test email sent" })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Error" }, { status: 400 })
  }
}
