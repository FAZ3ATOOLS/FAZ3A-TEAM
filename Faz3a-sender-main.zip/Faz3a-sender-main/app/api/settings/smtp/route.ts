import { type NextRequest, NextResponse } from "next/server"
import { assertCsrf, requireAdmin } from "@/lib/auth"
import { sql } from "@/lib/db"
import { seal } from "@/lib/crypto"
import { randomUUID } from "crypto"

export async function POST(req: NextRequest) {
  try {
    assertCsrf()
    const { sub } = await requireAdmin(req)
    const { host, port, secure, username, password, fromEmail, fromName } = await req.json()
    const enc = seal(password)
    const id = randomUUID()
    await sql`
      insert into smtp_credentials (id, user_id, host, port, secure, username, password_enc, from_email, from_name)
      values (${id}, ${sub}, ${host}, ${port}, ${secure}, ${username}, ${enc}, ${fromEmail}, ${fromName})
      on conflict (user_id) do update set host=excluded.host, port=excluded.port, secure=excluded.secure,
        username=excluded.username, password_enc=excluded.password_enc, from_email=excluded.from_email, from_name=excluded.from_name
    `
    return NextResponse.json({ message: "Saved" })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Error" }, { status: 400 })
  }
}
