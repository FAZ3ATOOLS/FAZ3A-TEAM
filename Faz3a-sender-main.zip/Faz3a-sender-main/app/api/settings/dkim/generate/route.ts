import { NextResponse, type NextRequest } from "next/server"
import { assertCsrf, requireAdmin } from "@/lib/auth"
import { sql } from "@/lib/db"
import { generateDkimKeypair, dkimTxtRecord, spfTxtRecord, dmarcTxtRecord } from "@/lib/dkim"

export async function POST(req: NextRequest) {
  try {
    assertCsrf()
    const { sub } = await requireAdmin(req)
    const { domain, selector } = await req.json()
    if (!domain || !selector) return NextResponse.json({ error: "domain and selector required" }, { status: 400 })

    const { publicKey, privateKey } = generateDkimKeypair()

    await sql`
      update smtp_credentials
      set dkim_domain=${domain}, dkim_selector=${selector}, dkim_private_key_pem=${privateKey}
      where user_id=${sub}
    `
    const dkim = dkimTxtRecord(selector, publicKey)
    const spf = spfTxtRecord(domain)
    const dmarc = dmarcTxtRecord(`postmaster@${domain}`)

    return NextResponse.json({
      ok: true,
      records: {
        dkim: { name: `${selector}._domainkey.${domain}`, value: dkim },
        spf: { name: domain, value: spf },
        dmarc: { name: `_dmarc.${domain}`, value: dmarc },
      },
      privateKey,
    })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Error" }, { status: 400 })
  }
}
