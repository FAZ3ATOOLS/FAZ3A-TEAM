"use client"

import React from "react"
import Navbar from "@/components/navbar"
import AppFooter from "@/components/footer"
import { LanguageProvider, useI18n } from "@/components/language-provider"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Table, TableHeader, TableHead, TableRow, TableBody, TableCell } from "@/components/ui/table"
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select"

type User = {
  id: string
  email: string
  role: "admin" | "user"
  status: "active" | "disabled"
  daily_quota: number | null
  campaign_quota: number | null
  created_at?: string
}

type LogRow = { id: string; user_id: string; action: string; meta: any; created_at: string; email: string }

function UsersInner() {
  const { t } = useI18n()
  const [users, setUsers] = React.useState<User[]>([])
  const [logs, setLogs] = React.useState<LogRow[]>([])
  const [open, setOpen] = React.useState(false)
  const [edit, setEdit] = React.useState<User | null>(null)
  const [form, setForm] = React.useState({
    email: "",
    password: "",
    role: "user" as "admin" | "user",
    status: "active" as "active" | "disabled",
    daily_quota: 500,
    campaign_quota: 1000,
  })
  const [msg, setMsg] = React.useState<string>("")

  async function load() {
    const res = await fetch("/api/admin/users", { cache: "no-store" })
    if (res.ok) {
      const j = await res.json()
      setUsers(j.users || [])
    }
    const r2 = await fetch("/api/admin/logs?limit=100", { cache: "no-store" })
    if (r2.ok) {
      const j2 = await r2.json()
      setLogs(j2.logs || [])
    }
  }
  React.useEffect(() => {
    load()
  }, [])

  function resetForm() {
    setForm({
      email: "",
      password: "",
      role: "user",
      status: "active",
      daily_quota: 500,
      campaign_quota: 1000,
    })
    setEdit(null)
  }

  async function saveUser() {
    setMsg("")
    const csrf = document.cookie
      .split("; ")
      .find((c) => c.startsWith("csrf_token="))
      ?.split("=")[1]
    if (!edit) {
      const res = await fetch("/api/admin/users", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-csrf-token": csrf || "" },
        body: JSON.stringify(form),
      })
      const j = await res.json().catch(() => ({}))
      if (res.ok) {
        setOpen(false)
        resetForm()
        load()
      } else setMsg(j?.error || "Error")
    } else {
      const res = await fetch(`/api/admin/users/${edit.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", "x-csrf-token": csrf || "" },
        body: JSON.stringify({
          role: form.role,
          status: form.status,
          daily_quota: form.daily_quota,
          campaign_quota: form.campaign_quota,
          password: form.password || undefined,
        }),
      })
      const j = await res.json().catch(() => ({}))
      if (res.ok) {
        setOpen(false)
        resetForm()
        load()
      } else setMsg(j?.error || "Error")
    }
  }

  async function deleteUser(id: string) {
    const csrf = document.cookie
      .split("; ")
      .find((c) => c.startsWith("csrf_token="))
      ?.split("=")[1]
    if (!confirm("Delete this user?")) return
    const res = await fetch(`/api/admin/users/${id}`, {
      method: "DELETE",
      headers: { "x-csrf-token": csrf || "" },
    })
    if (res.ok) load()
  }

  function onEdit(u: User) {
    setEdit(u)
    setForm({
      email: u.email,
      password: "",
      role: u.role,
      status: u.status,
      daily_quota: u.daily_quota ?? 0,
      campaign_quota: u.campaign_quota ?? 0,
    })
    setOpen(true)
  }

  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      <div className="mx-auto w-full max-w-7xl p-4 flex-1 space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-semibold">{t("adminPanel")}</h1>
          <Dialog
            open={open}
            onOpenChange={(v) => {
              setOpen(v)
              if (!v) resetForm()
            }}
          >
            <DialogTrigger asChild>
              <Button onClick={() => setOpen(true)}>{t("createUser")}</Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>{edit ? t("editUser") : t("createUser")}</DialogTitle>
              </DialogHeader>
              <div className="grid gap-3">
                <div className="grid gap-1">
                  <Label>{t("email")}</Label>
                  <Input
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder="user@company.com"
                    disabled={!!edit}
                  />
                </div>
                <div className="grid gap-1">
                  <Label>{t("password")}</Label>
                  <Input
                    type="password"
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                    placeholder={edit ? "(leave blank to keep current)" : "********"}
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="grid gap-1">
                    <Label>{t("role")}</Label>
                    <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v as any })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="user">User</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-1">
                    <Label>{t("status")}</Label>
                    <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v as any })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">{t("active")}</SelectItem>
                        <SelectItem value="disabled">{t("disabled")}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="grid gap-1">
                    <Label>{t("dailyQuota")}</Label>
                    <Input
                      type="number"
                      value={form.daily_quota}
                      onChange={(e) => setForm({ ...form, daily_quota: Number(e.target.value || "0") })}
                    />
                  </div>
                  <div className="grid gap-1">
                    <Label>{t("campaignQuota")}</Label>
                    <Input
                      type="number"
                      value={form.campaign_quota}
                      onChange={(e) => setForm({ ...form, campaign_quota: Number(e.target.value || "0") })}
                    />
                  </div>
                </div>
                {msg && <p className="text-sm text-red-600">{msg}</p>}
              </div>
              <DialogFooter className="mt-3">
                <Button variant="outline" onClick={() => setOpen(false)}>
                  {t("cancel")}
                </Button>
                <Button onClick={saveUser}>{edit ? t("update") : t("create")}</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>{t("users")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{t("email")}</TableHead>
                    <TableHead>{t("role")}</TableHead>
                    <TableHead>{t("status")}</TableHead>
                    <TableHead>{t("dailyQuota")}</TableHead>
                    <TableHead>{t("campaignQuota")}</TableHead>
                    <TableHead className="text-right">{t("actions")}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((u) => (
                    <TableRow key={u.id}>
                      <TableCell>{u.email}</TableCell>
                      <TableCell>{u.role}</TableCell>
                      <TableCell>{u.status}</TableCell>
                      <TableCell>{u.daily_quota ?? 0}</TableCell>
                      <TableCell>{u.campaign_quota ?? 0}</TableCell>
                      <TableCell className="text-right space-x-2">
                        <Button size="sm" variant="outline" onClick={() => onEdit(u)}>
                          {t("editUser")}
                        </Button>
                        <Button size="sm" variant="destructive" onClick={() => deleteUser(u.id)}>
                          {t("delete")}
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {users.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-sm text-muted-foreground">
                        No users
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>User Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>When</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Action</TableHead>
                    <TableHead>Meta</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {logs.map((l) => (
                    <TableRow key={l.id}>
                      <TableCell className="whitespace-nowrap">{new Date(l.created_at).toLocaleString()}</TableCell>
                      <TableCell className="whitespace-nowrap">{l.email || l.user_id}</TableCell>
                      <TableCell className="whitespace-nowrap">{l.action}</TableCell>
                      <TableCell className="max-w-[400px] overflow-hidden text-ellipsis">
                        <pre className="text-xs">{JSON.stringify(l.meta)}</pre>
                      </TableCell>
                    </TableRow>
                  ))}
                  {logs.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center text-sm text-muted-foreground">
                        No activity yet.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
      <AppFooter />
    </main>
  )
}

export default function AdminUsersPage() {
  return (
    <LanguageProvider>
      <UsersInner />
    </LanguageProvider>
  )
}
