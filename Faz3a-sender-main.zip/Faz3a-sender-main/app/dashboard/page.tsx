"use client"

import Navbar from "@/components/navbar"
import { LanguageProvider, useI18n } from "@/components/language-provider"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import React from "react"
import AppFooter from "@/components/footer"

function Bar({ value, max = 100 }: { value: number; max?: number }) {
  const pct = Math.max(0, Math.min(100, (value / (max || 1)) * 100))
  return (
    <div className="h-2 w-full bg-neutral-200 rounded">
      <div className="h-full bg-emerald-500 rounded" style={{ width: `${pct}%` }} />
    </div>
  )
}

function DashboardInner() {
  const { t } = useI18n()
  const [data, setData] = React.useState<any>(null)

  React.useEffect(() => {
    ;(async () => {
      try {
        const res = await fetch("/api/metrics/summary", { cache: "no-store" })
        if (res.ok) {
          const j = await res.json()
          setData(j)
        }
      } catch (error) {
        console.error("Failed to fetch metrics:", error)
      }
    })()
  }, [])

  const openRate = React.useMemo(() => {
    if (!data) return 0
    const totalSent = data.perCampaign?.reduce((acc: number, c: any) => acc + (c.sent || 0), 0) || 0
    const totalOpens = data.perCampaign?.reduce((acc: number, c: any) => acc + (c.opens || 0), 0) || 0
    return totalSent ? Math.round((totalOpens / totalSent) * 100) : 0
  }, [data])

  const clickRate = React.useMemo(() => {
    if (!data) return 0
    const totalSent = data.perCampaign?.reduce((acc: number, c: any) => acc + (c.sent || 0), 0) || 0
    const totalClicks = data.perCampaign?.reduce((acc: number, c: any) => acc + (c.clicks || 0), 0) || 0
    return totalSent ? Math.round((totalClicks / totalSent) * 100) : 0
  }, [data])

  const totalSent = data?.perCampaign?.reduce((acc: number, c: any) => acc + (c.sent || 0), 0) || 0
  const totalOpens = data?.perCampaign?.reduce((acc: number, c: any) => acc + (c.opens || 0), 0) || 0
  const totalClicks = data?.perCampaign?.reduce((acc: number, c: any) => acc + (c.clicks || 0), 0) || 0

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="mx-auto max-w-7xl p-4 space-y-6 flex-1">
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">{t("totalSent")}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalSent.toLocaleString()}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">{t("totalOpens")}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalOpens.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">{openRate}% rate</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">{t("totalClicks")}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalClicks.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">{clickRate}% rate</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">{t("totalBounces")}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{data?.bounces ?? 0}</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle>{t("recentCampaigns")}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {data?.perCampaign?.length ? (
                data.perCampaign.slice(0, 5).map((c: any) => {
                  const o = c.sent ? Math.round((c.opens / c.sent) * 100) : 0
                  const k = c.sent ? Math.round((c.clicks / c.sent) * 100) : 0
                  return (
                    <div key={c.campaign_id} className="border rounded p-3 space-y-2">
                      <div className="flex justify-between text-sm">
                        <div className="font-medium">{c.name || "Untitled Campaign"}</div>
                        <div className="text-muted-foreground">
                          {t("sent")}: {c.sent}
                        </div>
                      </div>
                      <div className="text-xs">
                        {t("opened")}: {c.opens} ({o}%)
                      </div>
                      <Bar value={o} />
                      <div className="text-xs mt-2">
                        {t("clicked")}: {c.clicks} ({k}%)
                      </div>
                      <Bar value={k} />
                    </div>
                  )
                })
              ) : (
                <div className="text-sm text-muted-foreground">{t("noCampaigns")}</div>
              )}
            </CardContent>
          </Card>

          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>Performance Overview</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Open Rate</span>
                  <span>{openRate}%</span>
                </div>
                <Bar value={openRate} />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Click Rate</span>
                  <span>{clickRate}%</span>
                </div>
                <Bar value={clickRate} />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Bounce Rate</span>
                  <span>{totalSent ? Math.round(((data?.bounces || 0) / totalSent) * 100) : 0}%</span>
                </div>
                <Bar value={totalSent ? ((data?.bounces || 0) / totalSent) * 100 : 0} />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      <AppFooter />
    </div>
  )
}

export default function DashboardPage() {
  return (
    <LanguageProvider>
      <DashboardInner />
    </LanguageProvider>
  )
}
