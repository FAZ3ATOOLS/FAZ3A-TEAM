"use client"

import React from "react"
import Navbar from "@/components/navbar"
import AppFooter from "@/components/footer"
import { LanguageProvider, useI18n } from "@/components/language-provider"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type Template = { id: string; name: string }

function CampaignsInner() {
  const { t } = useI18n()
  const [templates, setTemplates] = React.useState<Template[]>([])
  const [templateId, setTemplateId] = React.useState<string>("")
  const [name, setName] = React.useState("")
  const [subject, setSubject] = React.useState("")
  const [message, setMessage] = React.useState("")

  React.useEffect(() => {
    ;(async () => {
      const res = await fetch("/api/templates/list", { cache: "no-store" })
      if (res.ok) {
        const j = await res.json()
        setTemplates(j.templates || [])
      }
    })()
  }, [])

  async function createCampaign() {
    setMessage("")
    const csrf = document.cookie
      .split("; ")
      .find((c) => c.startsWith("csrf_token="))
      ?.split("=")[1]
    const res = await fetch("/api/campaigns/create", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-csrf-token": csrf || "" },
      body: JSON.stringify({ name, templateId, subject }),
    })
    const j = await res.json().catch(() => ({}))
    if (res.ok) {
      setMessage(`Campaign created. Enqueued: ${j.enqueued ?? 0}`)
      setName("")
      setSubject("")
      setTemplateId("")
    } else setMessage(j?.error || "Error")
  }

  return (
    <main>
      <Navbar />
      <div className="mx-auto max-w-4xl p-4 grid gap-4">
        <Card>
          <CardHeader>
            <CardTitle>{t("campaigns")}</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3">
            <Input placeholder="Campaign name" value={name} onChange={(e) => setName(e.target.value)} />
            <Input placeholder="Subject" value={subject} onChange={(e) => setSubject(e.target.value)} />
            <Select value={templateId} onValueChange={setTemplateId}>
              <SelectTrigger>
                <SelectValue placeholder="Select template" />
              </SelectTrigger>
              <SelectContent>
                {templates.map((tpl) => (
                  <SelectItem key={tpl.id} value={tpl.id}>
                    {tpl.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div>
              <Button onClick={createCampaign} disabled={!name || !subject || !templateId}>
                {t("save")}
              </Button>
            </div>
            {message && <p className="text-sm text-green-600">{message}</p>}
            <p className="text-xs text-muted-foreground">
              Active contacts will be enqueued automatically. Sending runs via cron every few minutes.
            </p>
          </CardContent>
        </Card>
      </div>
      <AppFooter />
    </main>
  )
}

export default function CampaignsPage() {
  return (
    <LanguageProvider>
      <CampaignsInner />
    </LanguageProvider>
  )
}
