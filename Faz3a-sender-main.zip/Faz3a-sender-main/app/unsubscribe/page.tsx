"use client"

import React from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function UnsubscribePage() {
  const [email, setEmail] = React.useState<string | null>(null)
  const [message, setMessage] = React.useState<string>("")

  React.useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const e = params.get("e")
    setEmail(e)
  }, [])

  async function submit() {
    const csrf = document.cookie
      .split("; ")
      .find((c) => c.startsWith("csrf_token="))
      ?.split("=")[1]
    const res = await fetch("/api/unsubscribe", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-csrf-token": csrf || "" },
      body: JSON.stringify({ email }),
    })
    const j = await res.json().catch(() => ({}))
    if (res.ok) setMessage("You have been unsubscribed.")
    else setMessage(j?.error || "Error.")
  }

  return (
    <main className="min-h-screen grid place-items-center p-4">
      <Card className="max-w-md w-full">
        <CardHeader>
          <CardTitle>Unsubscribe</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3">
          <p className="text-sm text-muted-foreground">
            {email ? `Unsubscribe ${email} from future emails?` : "Missing email address"}
          </p>
          <div>
            <Button onClick={submit} disabled={!email}>
              Confirm
            </Button>
          </div>
          {message && <p className="text-sm">{message}</p>}
        </CardContent>
      </Card>
    </main>
  )
}
