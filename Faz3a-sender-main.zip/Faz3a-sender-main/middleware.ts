import { NextResponse, type NextRequest } from "next/server"
import { jwtVerify } from "jose"

// Public endpoints (needed for onboarding flows and static assets)
const PUBLIC_PATHS = new Set<string>([
  "/", // login page
  "/api/auth/login",
  "/api/auth/refresh",
  "/api/verification",
  "/unsubscribe",
  "/api/unsubscribe",
  "/api/track/open",
  "/api/track/click",
])

function isPublic(path: string) {
  if (PUBLIC_PATHS.has(path)) return true
  if (path.startsWith("/_next")) return true
  if (path.startsWith("/favicon")) return true
  if (path.endsWith(".json") || path.endsWith(".png") || path.endsWith(".jpg") || path.endsWith(".svg")) return true
  return false
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl
  // Always ensure CSRF token cookie exists (double submit pattern)
  const res = NextResponse.next()
  if (!req.cookies.get("csrf_token")?.value) {
    const token = (globalThis.crypto as any)?.randomUUID?.() || Math.random().toString(36).slice(2)
    res.cookies.set("csrf_token", token, { httpOnly: false, sameSite: "lax", path: "/" })
  }

  if (isPublic(pathname)) return res

  // Cron endpoint is protected by header in the route
  if (pathname.startsWith("/api/cron/")) return NextResponse.next()

  const access = req.cookies.get("access_token")?.value
  if (!access) {
    const url = req.nextUrl.clone()
    url.pathname = "/"
    url.search = ""
    return NextResponse.redirect(url)
  }

  try {
    const secret = new TextEncoder().encode(process.env.JWT_SECRET)
    const verified = await jwtVerify(access, secret)
    const role = (verified.payload as any)?.role
    if (pathname.startsWith("/admin") && role !== "admin") {
      const url = req.nextUrl.clone()
      url.pathname = "/dashboard"
      url.search = ""
      return NextResponse.redirect(url)
    }
    return res
  } catch {
    const url = req.nextUrl.clone()
    url.pathname = "/"
    url.search = ""
    return NextResponse.redirect(url)
  }
}

export const config = {
  matcher: ["/((?!static|.*\\..*|_next).*)", "/api/:path*"],
}
