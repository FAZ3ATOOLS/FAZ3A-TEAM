"use client"

/**
 * Globally hides or removes intrusive "built with" badges such as an element with id/class "v0-built-with-button".
 *
 * How it works:
 * - Immediately injects a CSS override to hide known selectors to prevent flicker (FOUC).
 * - Uses a MutationObserver to remove/hide any instances added later by third-party scripts.
 *
 * Safe for Vercel/serverless since it runs only on the client. No external code is modified.
 */
import { useEffect } from "react"

const KNOWN_SELECTORS = [
  "#v0-built-with-button",
  ".v0-built-with-button",
  '[data-testid="v0-built-with-button"]',
  'a[href*="v0.dev"]',
]

function hideByCss() {
  const css = `
  ${KNOWN_SELECTORS.join(",")} {
    display: none !important;
    visibility: hidden !important;
    opacity: 0 !important;
    pointer-events: none !important;
  }
  `
  const style = document.createElement("style")
  style.setAttribute("data-hide-v0-badge", "true")
  style.appendChild(document.createTextNode(css))
  document.head.appendChild(style)
}

function removeNodes(root: ParentNode | Document) {
  for (const sel of KNOWN_SELECTORS) {
    root.querySelectorAll<HTMLElement>(sel).forEach((el) => {
      // Prefer remove; fallback to hide if removal is blocked
      try {
        el.remove()
      } catch {
        el.style.display = "none"
        el.style.visibility = "hidden"
        el.style.opacity = "0"
        el.style.pointerEvents = "none"
      }
    })
  }
}

export default function HideV0Badge() {
  useEffect(() => {
    if (typeof document === "undefined") return

    // 1) CSS hard override to avoid flicker
    hideByCss()

    // 2) Remove if already present
    removeNodes(document)

    // 3) Watch for dynamically injected nodes
    const observer = new MutationObserver((mutations) => {
      for (const m of mutations) {
        if (m.type === "childList" && (m.addedNodes?.length || 0) > 0) {
          m.addedNodes.forEach((n) => {
            if (!(n instanceof HTMLElement)) return
            // Remove known targets quickly
            for (const sel of KNOWN_SELECTORS) {
              if (n.matches?.(sel) || n.querySelector?.(sel)) {
                removeNodes(n)
              }
            }
          })
        }
        if (m.type === "attributes" && m.target instanceof HTMLElement) {
          // Re-check on attribute mutations (e.g., id/class set later)
          removeNodes(m.target)
        }
      }
    })

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["id", "class", "data-testid", "href"],
    })

    return () => observer.disconnect()
  }, [])

  // Renders nothing; it’s purely side-effects.
  return null
}
