"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

type Language = "en" | "ar"

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

const translations = {
  en: {
    appName: "FAZ3A Sender Email",
    email: "Email",
    password: "Password",
    signIn: "Sign In",
    dashboard: "Dashboard",
    contacts: "Contacts",
    campaigns: "Campaigns",
    templates: "Templates",
    settings: "Settings",
    admin: "Admin",
    users: "Users",
    logout: "Logout",
    welcome: "Welcome",
    totalSent: "Total Sent",
    totalOpens: "Total Opens",
    totalClicks: "Total Clicks",
    totalBounces: "Total Bounces",
    recentCampaigns: "Recent Campaigns",
    noCampaigns: "No campaigns yet",
    addContact: "Add Contact",
    importContacts: "Import Contacts",
    importCSV: "Import CSV",
    validate: "Validate & Import",
    createCampaign: "Create Campaign",
    createTemplate: "Create Template",
    smtpSettings: "SMTP Settings",
    smtpConfig: "SMTP Configuration",
    testEmail: "Test Email",
    dkimSettings: "DKIM Settings",
    userManagement: "User Management",
    adminPanel: "Admin Panel",
    createUser: "Create User",
    editUser: "Edit User",
    addUser: "Add User",
    name: "Name",
    status: "Status",
    role: "Role",
    dailyQuota: "Daily Quota",
    campaignQuota: "Campaign Quota",
    actions: "Actions",
    save: "Save",
    create: "Create",
    update: "Update",
    cancel: "Cancel",
    delete: "Delete",
    edit: "Edit",
    editor: "Editor",
    preview: "Preview",
    active: "Active",
    inactive: "Inactive",
    pending: "Pending",
    verified: "Verified",
    sent: "Sent",
    delivered: "Delivered",
    opened: "Opened",
    clicked: "Clicked",
    bounced: "Bounced",
    complained: "Complained",
    unsubscribed: "Unsubscribed",
  },
  ar: {
    appName: "FAZ3A مرسل البريد الإلكتروني",
    email: "البريد الإلكتروني",
    password: "كلمة المرور",
    signIn: "تسجيل الدخول",
    dashboard: "لوحة التحكم",
    contacts: "جهات الاتصال",
    campaigns: "الحملات",
    templates: "القوالب",
    settings: "الإعدادات",
    admin: "المدير",
    users: "المستخدمون",
    logout: "تسجيل الخروج",
    welcome: "مرحباً",
    totalSent: "إجمالي المرسل",
    totalOpens: "إجمالي المفتوح",
    totalClicks: "إجمالي النقرات",
    totalBounces: "إجمالي المرتد",
    recentCampaigns: "الحملات الأخيرة",
    noCampaigns: "لا توجد حملات بعد",
    addContact: "إضافة جهة اتصال",
    importContacts: "استيراد جهات الاتصال",
    importCSV: "استيراد CSV",
    validate: "التحقق والاستيراد",
    createCampaign: "إنشاء حملة",
    createTemplate: "إنشاء قالب",
    smtpSettings: "إعدادات SMTP",
    smtpConfig: "تكوين SMTP",
    testEmail: "اختبار البريد الإلكتروني",
    dkimSettings: "إعدادات DKIM",
    userManagement: "إدارة المستخدمين",
    adminPanel: "لوحة الإدارة",
    createUser: "إنشاء مستخدم",
    editUser: "تعديل المستخدم",
    addUser: "إضافة مستخدم",
    name: "الاسم",
    status: "الحالة",
    role: "الدور",
    dailyQuota: "الحصة اليومية",
    campaignQuota: "حصة الحملة",
    actions: "الإجراءات",
    save: "حفظ",
    create: "إنشاء",
    update: "تحديث",
    cancel: "إلغاء",
    delete: "حذف",
    edit: "تعديل",
    editor: "المحرر",
    preview: "معاينة",
    active: "نشط",
    inactive: "غير نشط",
    pending: "في الانتظار",
    verified: "مُتحقق",
    sent: "مُرسل",
    delivered: "مُسلم",
    opened: "مفتوح",
    clicked: "تم النقر",
    bounced: "مرتد",
    complained: "شكوى",
    unsubscribed: "ألغى الاشتراك",
  },
}

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>("en")

  useEffect(() => {
    const saved = localStorage.getItem("language") as Language
    if (saved && (saved === "en" || saved === "ar")) {
      setLanguage(saved)
      document.documentElement.lang = saved
      document.documentElement.dir = saved === "ar" ? "rtl" : "ltr"
    }
  }, [])

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang)
    localStorage.setItem("language", lang)
    document.documentElement.lang = lang
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr"
  }

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations.en] || key
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useI18n() {
  const context = useContext(LanguageContext)
  if (!context) {
    throw new Error("useI18n must be used within a LanguageProvider")
  }
  return context
}
