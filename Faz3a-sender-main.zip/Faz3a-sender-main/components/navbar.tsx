"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useI18n } from "./language-provider"
import React from "react"

export default function Navbar({ onLogout }: { onLogout?: () => void }) {
  const { t, language, setLanguage } = useI18n()
  const [role, setRole] = React.useState<"admin" | "user" | null>(null)

  React.useEffect(() => {
    ;(async () => {
      try {
        const res = await fetch("/api/me", { cache: "no-store" })
        if (res.ok) {
          const j = await res.json()
          setRole(j.role)
        }
      } catch {}
    })()
  }, [])

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" })
      window.location.href = "/"
    } catch (error) {
      console.error("Logout failed:", error)
    }
  }

  return (
    <header className="border-b bg-white/60 backdrop-blur supports-[backdrop-filter]:bg-white/40">
      <div className="mx-auto max-w-7xl px-4 py-3 flex items-center justify-between">
        <Link href="/dashboard" className="font-semibold text-xl tracking-tight">
          {t("appName")}
        </Link>
        <nav className="flex gap-3 items-center">
          <Link href="/dashboard" className="text-sm hover:underline">
            {t("dashboard")}
          </Link>
          <Link href="/contacts" className="text-sm hover:underline">
            {t("contacts")}
          </Link>
          <Link href="/campaigns" className="text-sm hover:underline">
            {t("campaigns")}
          </Link>
          <Link href="/templates" className="text-sm hover:underline">
            {t("templates")}
          </Link>
          <Link href="/settings" className="text-sm hover:underline">
            {t("settings")}
          </Link>
          {role === "admin" && (
            <Link href="/admin/users" className="text-sm font-medium hover:underline">
              {t("admin")}
            </Link>
          )}
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setLanguage(language === "en" ? "ar" : "en")}>
              {language === "en" ? "العربية" : "English"}
            </Button>
          </div>
          <Button variant="ghost" size="sm" onClick={onLogout || handleLogout}>
            {t("logout")}
          </Button>
        </nav>
      </div>
    </header>
  )
}
