"use client"

export default function AppFooter() {
  return (
    <footer className="mt-12 border-t bg-white/70 backdrop-blur">
      <div className="mx-auto max-w-7xl px-4 py-6 text-sm text-muted-foreground flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="text-center md:text-left">Developed and maintained by FAZ3A TEAM.</div>
        <div className="text-center md:text-right">Contact: @faz3ateamjo on Telegram • support@faz3a.info</div>
      </div>
    </footer>
  )
}
