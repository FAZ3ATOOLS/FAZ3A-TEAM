// Exponential backoff policy shared by queue processor and tests.
export function computeBackoffSeconds(retries: number) {
  const base = 30
  const max = 3600
  const exp = Math.pow(2, Math.max(0, retries)) * base
  return Math.min(max, exp)
}
