import { sql } from "./db"

export async function canSendForUser(userId: string, campaignId: string | null) {
  const [u] = await sql`
    select daily_quota, campaign_quota, status from users where id=${userId} limit 1
  `
  if (!u || u.status !== "active") return { ok: false, reason: "User inactive" }

  // Check daily quota
  if (u.daily_quota) {
    const [{ count: dailySent }] = await sql`
      select count(*)::int as count from queue 
      where user_id=${userId} and status='sent' and sent_at > now() - interval '24 hours'
    `
    if (dailySent >= u.daily_quota) return { ok: false, reason: "Daily quota exceeded" }
  }

  // Check campaign quota
  if (campaignId && u.campaign_quota) {
    const [{ count: campaignSent }] = await sql`
      select count(*)::int as count from queue 
      where user_id=${userId} and campaign_id=${campaignId} and status='sent'
    `
    if (campaignSent >= u.campaign_quota) return { ok: false, reason: "Campaign quota exceeded" }
  }

  return { ok: true }
}
