// Serverless Postgres client (Neon HTTP) — no native builds required.
// This module is safe on Vercel serverless functions. [^2]
import { neon } from "@neondatabase/serverless"

const connectionString = process.env.DATABASE_URL || process.env.POSTGRES_URL || process.env.POSTGRES_PRISMA_URL

if (!connectionString) {
  throw new Error(
    "DATABASE_URL is required. Configure it in Vercel Project Settings → Environment Variables (Production/Preview) [^1][^4].",
  )
}

// neon() is a tagged template for SQL. Usage: const rows = await sql`select 1 as x`
export const sql = neon(connectionString)

// Helper function for typed SQL queries
export async function sqlQuery<T>(query: any): Promise<T[]> {
  return await sql(query) as T[]
}
