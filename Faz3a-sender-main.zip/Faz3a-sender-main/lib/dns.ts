// MX lookup using DNS over HTTPS (Cloudflare). Free and no API key required.
// Note: Subject to external service availability, but not a paid dependency.
// If blocked, fallback or disable MX validation via env.
export type MxRecord = { preference: number; exchange: string }

export async function resolveMx(domain: string): Promise<MxRecord[]> {
  const url = `https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(domain)}&type=MX`
  const res = await fetch(url, {
    headers: { Accept: "application/dns-json" },
    cache: "no-store",
  })
  if (!res.ok) throw new Error(`DNS query failed: ${res.status}`)
  const json = await res.json()
  const answers = Array.isArray(json?.Answer) ? json.Answer : []
  const mx: MxRecord[] = []
  for (const a of answers) {
    if (a.type === 15 && typeof a.data === "string") {
      // data: "10 alt1.aspmx.l.google.com."
      const parts = a.data.split(" ")
      if (parts.length >= 2) {
        const pref = Number.parseInt(parts[0], 10)
        const exch = parts[1].replace(/\.$/, "")
        mx.push({ preference: pref, exchange: exch })
      }
    }
  }
  return mx.sort((a, b) => a.preference - b.preference)
}
