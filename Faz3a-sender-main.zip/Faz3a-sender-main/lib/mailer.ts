// Email sending utilities: external SMTP and (gated) direct-to-MX.
// For external SMTP, we use Nodemailer with optional DKIM.
// We inject tracking and unsubscribe headers via lib/email-content.
import { sql } from "./db"
import { open } from "./crypto"
import nodemailer from "nodemailer"

type SmtpCred = {
  id: string
  user_id: string
  host: string
  port: number
  secure: boolean
  username: string
  password_enc: string
  from_email: string
  from_name: string | null
  dkim_domain: string | null
  dkim_selector: string | null
  dkim_private_key_pem: string | null
}

export async function getSmtpCreds(userId: string): Promise<SmtpCred | null> {
  const rows = await sql`
    select id, user_id, host, port, secure, username, password_enc, from_email, from_name,
           dkim_domain, dkim_selector, dkim_private_key_pem
    from smtp_credentials where user_id=${userId} limit 1
  `
  if (rows.length === 0) return null
  
  const row = rows[0] as any
  return {
    id: row.id,
    user_id: row.user_id,
    host: row.host,
    port: row.port,
    secure: row.secure,
    username: row.username,
    password_enc: row.password_enc,
    from_email: row.from_email,
    from_name: row.from_name,
    dkim_domain: row.dkim_domain,
    dkim_selector: row.dkim_selector,
    dkim_private_key_pem: row.dkim_private_key_pem,
  }
}

type SendParams = {
  to: string
  subject: string
  rawHtml: string
  variables?: Record<string, any>
  token: string
  publicBaseUrl: string
}

type TransportOverride = nodemailer.Transporter | undefined

export async function sendViaExternalSmtp(userId: string, message: SendParams, override?: TransportOverride) {
  const creds = await getSmtpCreds(userId)
  if (!creds) throw new Error("SMTP credentials not configured")

  const password = open(creds.password_enc)
  const transport = override || nodemailer.createTransport({
    host: creds.host,
    port: creds.port,
    secure: creds.secure,
    auth: { user: creds.username, pass: password },
  })

  const html = message.rawHtml
  const { to, subject } = message

  await transport.sendMail({
    from: `"${creds.from_name || "MailForge"}" <${creds.from_email}>`,
    to,
    subject,
    html,
    headers: {
      "List-Unsubscribe": `<${message.publicBaseUrl}/api/unsubscribe?e=${encodeURIComponent(to)}>`,
      "List-Unsubscribe-Post": "List-Unsubscribe=One-Click",
    },
  })
}

export async function sendDirectToMx() {
  // This would implement direct-to-MX sending
  // Not implemented for serverless compatibility
  throw new Error("Direct MX sending not available in serverless environment")
}

export async function throttleOk(domain: string, mxHost: string | null, perMinuteDomain = 20, perMinuteMx = 30) {
  const now = new Date()
  const oneMinuteAgo = new Date(now.getTime() - 60 * 1000)

  // Check domain-level throttling
  const [{ count: dCount }] = await sql`
    select count(*)::int as count from send_quota 
    where domain=${domain} and ts > ${oneMinuteAgo}
  `
  if (dCount >= perMinuteDomain) return false

  // Check MX-level throttling
  if (mxHost) {
    const [{ count: mCount }] = await sql`
      select count(*)::int as count from send_quota 
      where mx_host=${mxHost} and ts > ${oneMinuteAgo}
    `
    if (mCount >= perMinuteMx) return false
  }

  // Record this send
  await sql`
    insert into send_quota (id, domain, mx_host, ts) 
    values (gen_random_uuid(), ${domain}, ${mxHost}, ${now})
  `

  return true
}

export async function resolveRecipientMx(toEmail: string) {
  const domain = toEmail.split("@")[1]
  if (!domain) throw new Error("Invalid email address")

  // For now, just return the domain
  // In a real implementation, you'd do actual MX resolution
  return { domain, mxHost: null }
}
