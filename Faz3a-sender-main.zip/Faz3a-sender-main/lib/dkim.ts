// DKIM key generation and DNS guidance
import { generateKeyPairSync } from "crypto"

export function generateDkimKeypair() {
  const { publicKey, privateKey } = generateKeyPairSync("rsa", {
    modulusLength: 2048,
    publicKeyEncoding: { type: "spki", format: "pem" },
    privateKeyEncoding: { type: "pkcs8", format: "pem" },
  })
  return { publicKey, privateKey }
}

export function dkimTxtRecord(selector: string, publicKeyPem: string) {
  // Extract base64 body from PEM
  const body = publicKeyPem
    .replace(/-----BEGIN PUBLIC KEY-----/g, "")
    .replace(/-----END PUBLIC KEY-----/g, "")
    .replace(/\s+/g, "")
  const v = "v=DKIM1; k=rsa; "
  const p = `p=${body};`
  return v + p
}

export function spfTxtRecord(sendingDomain: string) {
  // If you're using external SMTP, include their SPF mechanism (user-provided).
  // For direct sends from your infra (not Vercel), include the server IPs.
  return `v=spf1 a mx ~all`
}

export function dmarcTxtRecord(ruaEmail: string) {
  return `v=DMARC1; p=quarantine; rua=mailto:${ruaEmail}; fo=1; adkim=s; aspf=s`
}
