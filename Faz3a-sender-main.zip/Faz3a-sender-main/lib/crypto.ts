import { randomBytes, createCipheriv, createDecipheriv } from "crypto"

const ENC_ALGO = "aes-256-gcm"

function getKey() {
  const key = process.env.ENCRYPTION_KEY
  if (!key) throw new Error("ENCRYPTION_KEY is required (32 bytes hex)")
  const buf = Buffer.from(key, "hex")
  if (buf.length !== 32) throw new Error("ENCRYPTION_KEY must be 32 bytes hex")
  return buf
}

export function seal(plaintext: string) {
  const key = getKey()
  const iv = randomBytes(12)
  const cipher = createCipheriv(ENC_ALGO, key, iv)
  const enc = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()])
  const tag = cipher.getAuthTag()
  return Buffer.concat([iv, tag, enc]).toString("base64")
}

export function open(box: string) {
  const key = getKey()
  const buf = Buffer.from(box, "base64")
  const iv = buf.subarray(0, 12)
  const tag = buf.subarray(12, 28)
  const data = buf.subarray(28)
  const decipher = createDecipheriv(ENC_ALGO, key, iv)
  decipher.setAuthTag(tag)
  const dec = Buffer.concat([decipher.update(data), decipher.final()])
  return dec.toString("utf8")
}
