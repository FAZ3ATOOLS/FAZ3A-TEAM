import isEmail from "validator/lib/isEmail"
import { resolveMx } from "./dns"

const ROLE_BASED_LOCALPARTS = new Set([
  "admin",
  "administrator",
  "support",
  "info",
  "sales",
  "contact",
  "hello",
  "help",
  "billing",
  "abuse",
  "noc",
  "postmaster",
  "webmaster",
  "security",
])

// Small disposable list sample. In production, consider expanding this list.
const DISPOSABLE_DOMAINS = new Set([
  "mailinator.com",
  "guerrillamail.com",
  "10minutemail.com",
  "tempmail.email",
  "trashmail.com",
  "sharklasers.com",
])

export type ValidationResult = {
  syntaxValid: boolean
  hasMx: boolean
  roleBased: boolean
  disposable: boolean
  smtpProbe?: boolean
  valid: boolean
  details?: string
}

export async function validateEmailAddress(email: string): Promise<ValidationResult> {
  const lower = email.trim().toLowerCase()
  const syntax = isEmail(lower, { allow_utf8_local_part: true, require_tld: true })
  if (!syntax) {
    return {
      syntaxValid: false,
      hasMx: false,
      roleBased: false,
      disposable: false,
      valid: false,
      details: "Invalid syntax",
    }
  }
  const [local, domain] = lower.split("@")
  const roleBased = ROLE_BASED_LOCALPARTS.has(local)
  const disposable = DISPOSABLE_DOMAINS.has(domain)
  let hasMx = false
  let smtpProbe = undefined
  try {
    const mx = await resolveMx(domain)
    hasMx = mx.length > 0
  } catch (e: any) {
    return { syntaxValid: true, hasMx: false, roleBased, disposable, valid: false, details: "MX lookup failed" }
  }
  if (!hasMx) {
    return { syntaxValid: true, hasMx, roleBased, disposable, valid: false, details: "No MX records" }
  }

  if (process.env.ENABLE_SMTP_PROBE === "true") {
    // Optional SMTP probe. On Vercel serverless, raw TCP (port 25) is not available; running elsewhere may be required.
    // Implemented as a no-op here for serverless; you can run a separate worker to perform RCPT TO checks if needed.
    smtpProbe = false
  }

  const valid =
    syntax && hasMx && !disposable && !roleBased && (smtpProbe !== false || process.env.ENABLE_SMTP_PROBE !== "true")
  return { syntaxValid: syntax, hasMx, roleBased, disposable, smtpProbe, valid }
}
