import type { NextRequest } from "next/server"

export function publicBaseUrlFromReq(req: NextRequest) {
  const env = process.env.NEXT_PUBLIC_BASE_URL
  if (env) return env
  const proto = req.headers.get("x-forwarded-proto") || "https"
  const host = req.headers.get("host") || ""
  return `${proto}://${host}`
}
