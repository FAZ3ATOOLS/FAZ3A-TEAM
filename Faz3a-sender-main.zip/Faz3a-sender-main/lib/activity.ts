import { sql } from "./db"

export async function logActivity(userId: string, action: string, meta: Record<string, any> = {}) {
  await sql`
    insert into user_activity_logs (user_id, action, meta)
    values (${userId}, ${action}, ${JSON.stringify(meta)})
  `
}
