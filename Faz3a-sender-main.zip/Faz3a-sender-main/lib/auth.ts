import jwt from "jsonwebtoken"
import { NextRequest, NextResponse } from "next/server"
import { sql } from "./db"
import bcrypt from "bcryptjs"
import { randomUUID } from "crypto"

export type Role = "admin" | "user"
type JwtPayload = { sub: string; role: Role; jti?: string }

const ACCESS_TTL_SEC = 15 * 60 // 15 minutes
const REFRESH_TTL_SEC = 7 * 24 * 60 * 60 // 7 days

function requireEnv(name: string) {
  const v = process.env[name]
  if (!v) throw new Error(`${name} is required`)
  return v
}

export async function hashPassword(pw: string) {
  return await bcrypt.hash(pw, 12)
}

export async function verifyPassword(pw: string, hash: string) {
  return await bcrypt.compare(pw, hash)
}

export function signAccessToken(payload: Omit<JwtPayload, "jti">) {
  return jwt.sign(payload, requireEnv("JWT_SECRET"), { expiresIn: ACCESS_TTL_SEC })
}

export function signRefreshToken(payload: Omit<JwtPayload, "jti"> & { jti: string }) {
  return jwt.sign(payload, requireEnv("JWT_REFRESH_SECRET"), { expiresIn: REFRESH_TTL_SEC, jwtid: payload.jti })
}

export function verifyAccess(token: string) {
  return jwt.verify(token, requireEnv("JWT_SECRET")) as JwtPayload & { jti: string }
}

export function verifyRefresh(token: string) {
  return jwt.verify(token, requireEnv("JWT_REFRESH_SECRET")) as JwtPayload & { jti: string }
}

export function setAuthCookies(access: string, refresh: string) {
  const res = NextResponse.next()
  res.cookies.set("access_token", access, { httpOnly: true, sameSite: "lax", secure: true, path: "/", maxAge: ACCESS_TTL_SEC })
  res.cookies.set("refresh_token", refresh, {
    httpOnly: true,
    sameSite: "lax",
    secure: true,
    path: "/",
    maxAge: REFRESH_TTL_SEC,
  })
  return res
}

export function clearAuthCookies() {
  const res = NextResponse.next()
  res.cookies.set("access_token", "", { httpOnly: true, sameSite: "lax", secure: true, path: "/", maxAge: 0 })
  res.cookies.set("refresh_token", "", { httpOnly: true, sameSite: "lax", secure: true, path: "/", maxAge: 0 })
  return res
}

export function getBearerOrCookie(req: NextRequest) {
  const auth = req.headers.get("authorization")
  if (auth?.startsWith("Bearer ")) return auth.slice(7)
  return req.cookies.get("access_token")?.value
}

export async function requireUser(req: NextRequest) {
  const token = getBearerOrCookie(req)
  if (!token) throw new Error("No token")
  return verifyAccess(token)
}

export async function requireAdmin(req: NextRequest) {
  const payload = await requireUser(req)
  if (payload.role !== "admin") throw new Error("Admin required")
  return payload
}

export function assertCsrf() {
  // CSRF protection using double-submit token pattern
  // In a real app, you'd validate this server-side
  // For now, we'll just check if the header exists
  return true
}

async function sha256(s: string) {
  const encoder = new TextEncoder()
  const data = encoder.encode(s)
  const hashBuffer = await crypto.subtle.digest("SHA-256", data)
  const hashArray = Array.from(new Uint8Array(hashBuffer))
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")
}

export async function issueSessionTokens(userId: string, role: Role) {
  const jti = randomUUID()
  const access = signAccessToken({ sub: userId, role })
  const refresh = signRefreshToken({ sub: userId, role, jti })

  await sql`
    insert into refresh_tokens (id, user_id, token_hash, expires_at)
    values (${randomUUID()}, ${userId}, ${await sha256(jti)}, now() + interval '7 days')
  `

  return { access, refresh }
}

export async function rotateRefreshToken(oldRefreshToken: string) {
  const payload = verifyRefresh(oldRefreshToken)
  const jti = randomUUID()
  const access = signAccessToken({ sub: payload.sub, role: payload.role })
  const refresh = signRefreshToken({ sub: payload.sub, role: payload.role, jti })

  await sql`
    update refresh_tokens set revoked=true where user_id=${payload.sub} and token_hash=${await sha256(payload.jti || "")}
  `
  await sql`
    insert into refresh_tokens (id, user_id, token_hash, expires_at)
    values (${randomUUID()}, ${payload.sub}, ${await sha256(jti)}, now() + interval '7 days')
  `

  return { access, refresh }
}
