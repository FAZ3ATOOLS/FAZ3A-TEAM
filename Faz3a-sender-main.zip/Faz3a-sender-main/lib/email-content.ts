// Email content utilities: sanitization, variable rendering, link rewriting (click tracking),
// open tracking pixel injection, unsubscribe enforcement, and headers.
import createDOMPurify from "isomorphic-dompurify"
import Mustache from "mustache"

// Ensures every email includes a clear unsubscribe link and tracking.
// token: unique per recipient/campaign token
// publicBaseUrl: your deployment origin, e.g., https://yourdomain.com
export function prepareEmailHtml({
  html,
  variables,
  token,
  publicBaseUrl,
  unsubscribeEmail,
}: {
  html: string
  variables: Record<string, any>
  token: string
  publicBaseUrl: string
  unsubscribeEmail: string
}) {
  // Render variables using Mustache-style.
  const rendered = Mustache.render(html, variables)

  // Sanitize to reduce XSS or malicious injection.
  const clean = createDOMPurify.sanitize(rendered, { USE_PROFILES: { html: true } })

  // Rewrite links for click tracking.
  const rewritten = rewriteLinksForTracking(clean, token, publicBaseUrl)

  // Ensure unsubscribe footer.
  const withUnsub = ensureUnsubscribe(rewritten, publicBaseUrl, unsubscribeEmail)

  // Append open tracking pixel.
  const withPixel =
    withUnsub +
    `<img src="${publicBaseUrl}/api/track/open?t=${encodeURIComponent(token)}" alt="" width="1" height="1" style="display:none;" />`

  return withPixel
}

// Replace all href links with tracking redirect: /api/track/click?u=<url>&t=<token>
function rewriteLinksForTracking(html: string, token: string, publicBaseUrl: string) {
  // Simple regex-based rewrite for anchor tags. This won't catch all edge cases but covers typical templates.
  return html.replace(/<a\s+([^>]*?)href="([^"]+)"([^>]*)>/gi, (match, pre, href, post) => {
    // Only rewrite http/https links
    if (!/^https?:\/\//i.test(href)) return match
    const tracked = `${publicBaseUrl}/api/track/click?u=${encodeURIComponent(href)}&t=${encodeURIComponent(token)}`
    return `<a ${pre}href="${tracked}"${post}>`
  })
}

function ensureUnsubscribe(html: string, publicBaseUrl: string, email: string) {
  const unsubscribeUrl = `${publicBaseUrl}/unsubscribe?e=${encodeURIComponent(email)}`
  const footer = `
    <hr style="margin-top:24px;margin-bottom:16px;border:none;border-top:1px solid #e5e7eb;" />
    <p style="font-size:12px;color:#6b7280;">
      If you no longer wish to receive these emails, you can
      <a href="${unsubscribeUrl}">unsubscribe</a> at any time.
    </p>
  `
  // If already contains the word "unsubscribe", don't duplicate overly; but ensure at least one link exists.
  if (/unsubscribe/i.test(html)) return html
  return html + footer
}

export function listUnsubscribeHeaders(publicBaseUrl: string, email: string) {
  const url = `${publicBaseUrl}/unsubscribe?e=${encodeURIComponent(email)}`
  // Both mailto and URL recommended.
  return {
    "List-Unsubscribe": `<${url}>, <mailto:${email}?subject=unsubscribe>`,
    "List-Unsubscribe-Post": "List-Unsubscribe=One-Click",
  }
}
