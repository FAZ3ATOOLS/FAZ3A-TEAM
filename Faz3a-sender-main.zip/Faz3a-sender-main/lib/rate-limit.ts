import { sql } from "./db"

export async function checkRateLimit(key: string, limit: number, windowSec: number) {
  const now = new Date()
  const windowStart = new Date(now.getTime() - windowSec * 1000)

  const rows = await sql`
    select count(*)::int as count from rate_limits 
    where key=${key} and ts > ${windowStart}
  `
  const count = rows[0]?.count || 0

  if (count >= limit) return false

  await sql`
    insert into rate_limits (id, key, ts) 
    values (gen_random_uuid(), ${key}, ${now})
  `

  return true
}
