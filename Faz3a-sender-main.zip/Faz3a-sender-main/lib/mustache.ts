import Mustache from "mustache"

export function renderTemplate(html: string, variables: Record<string, any>) {
  return Mustache.render(html, variables)
}
