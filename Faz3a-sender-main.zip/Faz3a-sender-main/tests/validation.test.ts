import { describe, it, expect } from "vitest"
import { validateEmailAddress } from "../lib/validation"

describe("email validation pipeline", () => {
  it("rejects invalid syntax", async () => {
    const res = await validateEmailAddress("not-an-email")
    expect(res.valid).toBe(false)
    expect(res.syntaxValid).toBe(false)
  })
  it("flags role-based and disposable", async () => {
    const res = await validateEmailAddress("info@mailinator.com")
    expect(res.roleBased).toBe(true)
    expect(res.disposable).toBe(true)
    expect(res.valid).toBe(false)
  })
  it("passes a domain with MX", async () => {
    const res = await validateEmailAddress("someone@gmail.com")
    expect(res.syntaxValid).toBe(true)
    expect(res.hasMx).toBe(true)
  })
})
