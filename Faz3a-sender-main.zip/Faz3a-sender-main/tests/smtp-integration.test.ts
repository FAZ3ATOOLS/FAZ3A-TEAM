import { describe, it, expect, beforeAll, afterAll } from "vitest"
import { SMTPServer } from "smtp-server"
import nodemailer from "nodemailer"

describe("SMTP Integration", () => {
  let server: SMTPServer
  let port: number

  beforeAll(async () => {
    port = 2525
    server = new SMTPServer({
      onData(stream: any, session: any, callback: any) {
        let data = ""
        stream.on("data", (chunk: any) => {
          data += chunk
        })
        stream.on("end", () => {
          callback()
        })
      },
    })

    await new Promise<void>((resolve) => {
      server.listen(port, () => resolve())
    })
  })

  afterAll(async () => {
    await new Promise<void>((resolve) => {
      server.close(() => resolve())
    })
  })

  it("should send email via SMTP", async () => {
    const transporter = nodemailer.createTransport({
      host: "localhost",
      port,
      secure: false,
      ignoreTLS: true,
    })

    const info = await transporter.sendMail({
      from: "test@example.com",
      to: "recipient@example.com",
      subject: "Test",
      text: "Test email",
    })

    expect(info.messageId).toBeDefined()
  })
})
