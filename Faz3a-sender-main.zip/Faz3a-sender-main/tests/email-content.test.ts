import { describe, it, expect } from "vitest"
import { prepareEmailHtml } from "../lib/email-content"

describe("email content", () => {
  it("renders variables, rewrites links, adds pixel and unsubscribe", () => {
    const out = prepareEmailHtml({
      html: `<p>Hello {{name}}</p><a href="https://example.com">Go</a>`,
      variables: { name: "Friend" },
      token: "tkn",
      publicBaseUrl: "https://site.test",
      unsubscribeEmail: "user@example.com",
    })
    expect(out).toContain("Hello Friend")
    expect(out).toContain("/api/track/click?u=https%3A%2F%2Fexample.com&t=tkn")
    expect(out).toContain("/api/track/open?t=tkn")
    expect(out).toMatch(/unsubscribe/i)
  })
})
