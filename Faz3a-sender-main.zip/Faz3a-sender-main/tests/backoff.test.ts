import { describe, it, expect } from "vitest"
import { computeBackoffSeconds } from "../lib/backoff"

describe("backoff", () => {
  it("grows exponentially and caps at 3600", () => {
    expect(computeBackoffSeconds(0)).toBe(30)
    expect(computeBackoffSeconds(1)).toBe(60)
    expect(computeBackoffSeconds(2)).toBe(120)
    expect(computeBackoffSeconds(5)).toBe(960)
    expect(computeBackoffSeconds(10)).toBeLessThanOrEqual(3600)
    expect(computeBackoffSeconds(20)).toBe(3600)
  })
})
