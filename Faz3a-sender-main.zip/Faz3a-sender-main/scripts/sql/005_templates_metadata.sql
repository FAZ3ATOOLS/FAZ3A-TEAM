alter table if exists templates
  add column if not exists updated_at timestamp with time zone default now(),
  add column if not exists deleted boolean default false;

create index if not exists templates_updated_at_idx on templates (updated_at desc);
