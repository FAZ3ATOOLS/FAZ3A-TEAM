-- Refresh token rotation + blacklist table

create table if not exists refresh_tokens (
  id uuid primary key,
  user_id uuid not null,
  jti text not null unique,
  token_hash text not null,
  revoked boolean not null default false,
  expires_at timestamp with time zone not null,
  created_at timestamp with time zone not null default now()
);

create index if not exists refresh_tokens_user_idx on refresh_tokens (user_id);
create index if not exists refresh_tokens_expires_idx on refresh_tokens (expires_at);
