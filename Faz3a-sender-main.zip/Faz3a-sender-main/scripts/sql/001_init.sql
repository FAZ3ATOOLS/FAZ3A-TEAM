-- Initial schema for MailForge

create table if not exists users (
  id uuid primary key,
  email text unique not null,
  password_hash text not null,
  role text not null default 'admin'
);

create table if not exists contacts (
  id uuid primary key,
  email text unique not null,
  name text,
  status text not null default 'pending', -- pending, active, bounced, unsubscribed
  created_at timestamp with time zone default now()
);

create table if not exists verifications (
  id uuid primary key,
  email text not null,
  token text not null unique,
  created_at timestamp with time zone default now(),
  used boolean default false
);

create table if not exists templates (
  id uuid primary key,
  name text not null,
  html text not null,
  created_at timestamp with time zone default now()
);

create table if not exists campaigns (
  id uuid primary key,
  name text not null,
  template_id uuid references templates(id),
  created_at timestamp with time zone default now()
);

create table if not exists queue (
  id uuid primary key,
  user_id uuid not null,
  campaign_id uuid,
  to_email text not null,
  subject text not null,
  html text not null,
  status text not null default 'pending',
  retries int not null default 0,
  run_after timestamp with time zone default now(),
  created_at timestamp with time zone default now(),
  sent_at timestamp with time zone,
  error text
);

create index if not exists queue_pending_idx on queue (status, created_at);

create table if not exists events (
  id bigserial primary key,
  type text not null, -- open, click, bounce, delivered
  token text,
  meta jsonb not null default '{}',
  created_at timestamp with time zone default now()
);

create table if not exists rate_limits (
  id uuid primary key,
  key text not null,
  ts timestamp with time zone not null
);

create index if not exists rate_limits_key_ts on rate_limits (key, ts);

create table if not exists smtp_credentials (
  id uuid primary key,
  user_id uuid unique not null,
  host text not null,
  port int not null,
  secure boolean not null default false,
  username text not null,
  password_enc text not null,
  from_email text not null,
  from_name text,
  dkim_domain text,
  dkim_selector text,
  dkim_private_key_pem text
);
