-- Fix rate_limits table by adding missing id column
-- This migration fixes the "column 'id' of relation 'rate_limits' does not exist" error

-- Add id column if it doesn't exist
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'rate_limits' AND column_name = 'id'
    ) THEN
        ALTER TABLE rate_limits ADD COLUMN id uuid DEFAULT gen_random_uuid();
        ALTER TABLE rate_limits ALTER COLUMN id SET NOT NULL;
        ALTER TABLE rate_limits ADD PRIMARY KEY (id);
    END IF;
END $$;

-- Update any existing rows to have proper UUIDs
UPDATE rate_limits SET id = gen_random_uuid() WHERE id IS NULL;
