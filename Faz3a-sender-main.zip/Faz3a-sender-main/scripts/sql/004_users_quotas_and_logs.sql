-- Extend users with quotas and lifecycle fields. Create user activity logs.

alter table users
  add column if not exists status text not null default 'active',
  add column if not exists daily_quota int not null default 500,
  add column if not exists campaign_quota int not null default 1000,
  add column if not exists created_at timestamp with time zone default now(),
  add column if not exists updated_at timestamp with time zone default now(),
  add column if not exists last_login_at timestamp with time zone;

create table if not exists user_activity_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  action text not null,
  meta jsonb not null default '{}',
  created_at timestamp with time zone not null default now()
);

create index if not exists user_activity_logs_user_idx on user_activity_logs (user_id, created_at desc);
