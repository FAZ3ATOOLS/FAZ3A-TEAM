-- Enable required extensions for UUIDs and crypto. Safe to run multiple times.
-- Run this before other migrations.
BEGIN;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
COMMIT;
