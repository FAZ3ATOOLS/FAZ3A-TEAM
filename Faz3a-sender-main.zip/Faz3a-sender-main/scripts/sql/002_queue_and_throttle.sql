-- Queue enhancements: token + sending_mode and throttle ledger
alter table queue add column if not exists token text;
alter table queue add column if not exists sending_mode text default 'auto';

create table if not exists send_quota (
  id bigserial primary key,
  domain text not null,
  mx_host text,
  ts timestamp with time zone not null
);

create index if not exists send_quota_ts_idx on send_quota (ts);
create index if not exists send_quota_domain_ts on send_quota (domain, ts);
create index if not exists send_quota_mx_ts on send_quota (mx_host, ts);
