-- Convenience meta-migration for local/dev: run core schema and indexes
\i scripts/sql/000_enable_extensions.sql
\i scripts/sql/001_init.sql
\i scripts/sql/002_queue_and_throttle.sql
\i scripts/sql/003_refresh_tokens.sql
\i scripts/sql/004_users_quotas_and_logs.sql
