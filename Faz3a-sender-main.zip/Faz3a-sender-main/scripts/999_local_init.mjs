#!/usr/bin/env node

/**
 * Local database initialization script
 * Runs all SQL migrations in sequence for development setup
 */

const { Client } = require("pg")
const fs = require("fs")
const path = require("path")

async function runMigrations() {
  const client = new Client({
    connectionString: process.env.DATABASE_URL || process.env.POSTGRES_URL,
  })

  try {
    await client.connect()
    console.log("✓ Connected to database")

    const sqlDir = path.join(__dirname, "sql")
    const migrations = [
      "000_enable_extensions.sql",
      "001_init.sql",
      "002_queue_and_throttle.sql",
      "003_refresh_tokens.sql",
      "004_users_quotas_and_logs.sql",
    ]

    for (const migration of migrations) {
      const filePath = path.join(sqlDir, migration)
      if (fs.existsSync(filePath)) {
        console.log(`Running ${migration}...`)
        const sql = fs.readFileSync(filePath, "utf8")
        await client.query(sql)
        console.log(`✓ ${migration} completed`)
      } else {
        console.warn(`⚠ ${migration} not found, skipping`)
      }
    }

    console.log("🎉 All migrations completed successfully")
  } catch (error) {
    console.error("❌ Migration failed:", error)
    process.exit(1)
  } finally {
    await client.end()
  }
}

if (require.main === module) {
  runMigrations()
}

module.exports = { runMigrations }
