#!/usr/bin/env node

const { Client } = require("pg")
const bcrypt = require("bcryptjs")
const { v4: uuidv4 } = require("uuid")
const url = require("node:url")

function exitWith(msg, code = 1) {
  console.error(msg)
  process.exit(code)
}

function validatePassword(pw) {
  if (typeof pw !== "string") return false
  if (pw.length < 16) return false
  if (!/[A-Z]/.test(pw)) return false
  if (!/[a-z]/.test(pw)) return false
  if (!/[0-9]/.test(pw)) return false
  if (!/[^A-Za-z0-9]/.test(pw)) return false
  if (/\s/.test(pw)) return false
  return true
}
;(async () => {
  // Load from .env.local if not already set
  try {
    if (!process.env.DATABASE_URL || !process.env.ADMIN_EMAIL || !process.env.ADMIN_PASSWORD) {
      const fs = require("fs")
      if (fs.existsSync(".env.local")) {
        const raw = fs.readFileSync(".env.local", "utf8")
        for (const line of raw.split(/\r?\n/)) {
          if (!line || line.trim().startsWith("#")) continue
          const idx = line.indexOf("=")
          if (idx === -1) continue
          const key = line.slice(0, idx).trim()
          const val = line.slice(idx + 1).trim()
          if (!(key in process.env)) process.env[key] = val
        }
      }
    }
  } catch {}

  const DATABASE_URL = process.env.DATABASE_URL
  const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || "").trim().toLowerCase()
  const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || ""

  if (!DATABASE_URL) exitWith("ERROR: DATABASE_URL is required.")
  if (!ADMIN_EMAIL) exitWith("ERROR: ADMIN_EMAIL is required.")
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(ADMIN_EMAIL)) exitWith("ERROR: ADMIN_EMAIL must be a valid email address.")
  if (!ADMIN_PASSWORD) exitWith("ERROR: ADMIN_PASSWORD is required.")
  if (ADMIN_PASSWORD.length < 16) {
    console.warn(
      "WARNING: ADMIN_PASSWORD is shorter than 16 characters. It is recommended to use a strong, long password.",
    )
  }

  // Decide SSL: enable if DATABASE_SSL=true or sslmode=require present in URL.
  const dbUrl = new url.URL(DATABASE_URL)
  const sslRequire = dbUrl.searchParams.get("sslmode") === "require" || process.env.DATABASE_SSL === "true"

  const client = new Client({
    connectionString: DATABASE_URL,
    ssl: sslRequire ? { rejectUnauthorized: false } : undefined,
  })

  try {
    console.log("Connecting to database...")
    await client.connect()

    // Ensure users table exists (id uuid, email unique, password_hash, role)
    // If your migrations already created it, this is a no-op.
    const createTableSQL = `
      CREATE TABLE IF NOT EXISTS users (
        id UUID PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user',
        status TEXT NOT NULL DEFAULT 'active',
        created_at TIMESTAMPTZ NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_users_email ON users (email);
    `
    await client.query(createTableSQL)

    console.log(`Checking for existing admin with email: ${ADMIN_EMAIL}`)
    const existing = await client.query("SELECT id, role, status FROM users WHERE email = $1 LIMIT 1", [ADMIN_EMAIL])
    if (existing.rows.length > 0) {
      const { id, role, status } = existing.rows[0]
      let changed = false
      if (role !== "admin") {
        console.log("User exists but is not admin. Promoting to admin...")
        await client.query("UPDATE users SET role='admin' WHERE id=$1", [id])
        changed = true
      }
      if (status !== "active") {
        console.log("Activating existing user...")
        await client.query("UPDATE users SET status='active' WHERE id=$1", [id])
        changed = true
      }
      if (ADMIN_PASSWORD) {
        console.log("Updating existing user's password...")
        const newHash = await bcrypt.hash(ADMIN_PASSWORD, 10)
        await client.query("UPDATE users SET password_hash=$1 WHERE id=$2", [newHash, id])
        changed = true
      }
      if (changed) console.log("Success: Existing admin updated.")
      else console.log("Info: Admin user already exists. No changes made.")
      await client.end()
      process.exit(0)
    }

    console.log("Hashing password with bcrypt (saltRounds=10)...")
    const passwordHash = await bcrypt.hash(ADMIN_PASSWORD, 10)
    const id = uuidv4()

    const insertSQL = `
      INSERT INTO users (id, email, password_hash, role)
      VALUES ($1, $2, $3, 'admin')
      ON CONFLICT (email) DO NOTHING
      RETURNING id
    `
    const res = await client.query(insertSQL, [id, ADMIN_EMAIL, passwordHash])

    if (res.rows.length === 1) {
      console.log(`Success: Admin user seeded. id=${res.rows[0].id}`)
      process.exit(0)
    } else {
      console.log("Info: Admin already present or insert ignored by ON CONFLICT. No new user created.")
      process.exit(0)
    }
  } catch (err) {
    console.error("ERROR: Failed to seed admin user.")
    console.error(err && err.stack ? err.stack : err)
    process.exit(1)
  } finally {
    try {
      await client.end()
    } catch {
      // ignore
    }
  }
})()
